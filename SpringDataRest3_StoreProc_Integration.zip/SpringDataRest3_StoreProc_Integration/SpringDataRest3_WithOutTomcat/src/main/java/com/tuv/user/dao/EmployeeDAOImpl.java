package com.tuv.user.dao;

import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.tuv.user.bo.Employee;

//import com.tuv.user.bo.Employee;


@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	
	//@Autowired
	private SimpleJdbcCall simpleJdbcCall;
	
	
	EmployeeDAOImpl(DataSource dataSource){
		System.out.println("dataSource::: " + dataSource);
		this.dataSource=dataSource;
		 this.simpleJdbcCall = new SimpleJdbcCall(this.dataSource).withCatalogName("TUV").withProcedureName("getEmpRecord");
	}
	//@Autowired
	 private DataSource dataSource;
	
	/*// @Autowired
	 public void setDataSource(DataSource dataSource) {
	  this.dataSource = dataSource;
	  System.out.println("dataSource:::: "+dataSource);
	  this.simpleJdbcCall = new SimpleJdbcCall(this.dataSource).withProcedureName("getEmpRecord1");
	 }*/

	@Override
	public Employee getEmployee(int empId) {
		
		SqlParameterSource in = new MapSqlParameterSource().addValue("in_empid", empId);
		System.out.println("simpleJdbcCall"+simpleJdbcCall);
		   Map out = simpleJdbcCall.execute(in);
		   Employee employee = new Employee();
		   employee.setEmpid(empId);
		   employee.setName((String)out.get("out_name"));
		   employee.setAge((Integer)out.get("out_age"));
		   employee.setSalary(Long.valueOf((String)out.get("out_salary")));
		   return employee;
		// TODO Auto-generated method stub
		
	}

}
