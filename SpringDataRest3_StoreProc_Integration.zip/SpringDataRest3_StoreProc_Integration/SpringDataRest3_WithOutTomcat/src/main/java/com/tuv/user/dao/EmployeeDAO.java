package com.tuv.user.dao;

import org.springframework.stereotype.Repository;

import com.tuv.user.bo.Employee;

@Repository
public interface EmployeeDAO {

	public Employee getEmployee(int empId);
}
