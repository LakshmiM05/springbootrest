package com.tuv.user.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tuv.user.bo.Employee;

import com.tuv.user.dao.EmployeeDAO;


//@Component
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDAO employeeDAO;
	@Override
	public Employee getEmployee(int empId) {
		
		// TODO Auto-generated method stub
		//userRepository.getUser(id);
		return employeeDAO.getEmployee(empId);
	}
	

}
