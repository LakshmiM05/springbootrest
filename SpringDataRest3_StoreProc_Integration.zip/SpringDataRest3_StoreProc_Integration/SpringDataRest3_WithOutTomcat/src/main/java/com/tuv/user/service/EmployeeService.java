package com.tuv.user.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tuv.user.bo.Employee;


//@Component
@Service
public interface EmployeeService {

	public Employee getEmployee(int id);
}
