package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	
	@RequestMapping("/restservice/customer")

	public String getCustomer() {
		System.out.println("Inside Customer");
		return "Customer*************";
	}
	
	
	

}
