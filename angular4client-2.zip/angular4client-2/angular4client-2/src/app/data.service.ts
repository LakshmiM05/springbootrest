import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';

import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';


import { Customer } from './customer';

@Injectable()
export class DataService {
data: any = null;

  private customersUrl = 'SpringDataRest/rest/userdetails/test';  // URL to web API

  constructor(private _http: Http) {
    this.getMyBlog();
  }

  // Get all customers
  getCustomers(){
     
              
  }
  
  private getMyBlog() {
    return this._http.get(this.customersUrl)
                .map((res: Response) => res.json())
                 .subscribe(data => {
                        this.data = data;
                        console.log(this.data);
                });
  }

  private handleError(error: any): Promise<any> {
    console.error('Error', error); // for demo purposes only
    return Promise.reject(error.message || error);
  }
}
