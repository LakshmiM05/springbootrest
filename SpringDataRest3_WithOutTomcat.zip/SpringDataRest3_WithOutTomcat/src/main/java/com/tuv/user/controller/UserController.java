package com.tuv.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tuv.user.bo.User;
import com.tuv.user.service.UserService;

@RestController
public class UserController {

	@Autowired 
	private UserService userService;

	//@RequestMapping(value = "/user/{name}", method = RequestMethod.GET)
	@RequestMapping("rest/userdetails/{name}")
	public User getUser(@PathVariable("name") String name) {
		System.out.println("Inside User Controller");
		//userService = new UserServiceImpl();
		return userService.getUser(name);
		// return new ResponseEntity<User>(userService.getUser(id),
		// HttpStatus.OK);

	}

	@RequestMapping("rest/api/helloworld")

	public String helloWorld() {
		System.out.println("Inside Hello World");
		return "Hello World from Restful API";
	}
}
