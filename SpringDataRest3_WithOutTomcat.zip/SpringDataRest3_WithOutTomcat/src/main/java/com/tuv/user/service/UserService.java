package com.tuv.user.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tuv.user.bo.User;

//@Component
@Service
public interface UserService {

	public User getUser(String name);
}
