package com.att.tuv.controller.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.tuv.entity.Employee;
import com.att.tuv.service.employee.EmployeeService;



@RestController
public class EmployeeController {
	
	@Autowired 
	private EmployeeService empService;
	
	@RequestMapping("organization/employee1/{id}, method = RequestMethod.GET")
	public Employee getEmployee(@PathVariable("id") int id) {
		System.out.println("Inside User Controller:::::" + id);		
		return empService.getEmployee(id);		
	}
	
	@RequestMapping("organization/employee")
	public List<Employee> getAllEmployee() {
		System.out.println("Inside User Controller:::::" );		
		return empService.getAllEmployee();		
	}

}
