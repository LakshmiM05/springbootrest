package com.att.tuv.service.employee;


import java.util.List;

import org.springframework.stereotype.Service;

import com.att.tuv.entity.Employee;


@Service
public interface EmployeeService {
	public Employee getEmployee(int id);

	public List<Employee> getAllEmployee();
}
