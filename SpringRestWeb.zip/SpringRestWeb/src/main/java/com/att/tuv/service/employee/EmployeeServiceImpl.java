package com.att.tuv.service.employee;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.att.tuv.dao.employee.EmployeeDAO;
import com.att.tuv.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDAO employeeDAO;	
	
	public Employee getEmployee(int empId) {			
		return employeeDAO.getEmployee(empId);
	}

	//@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployee();
	}
	

}
