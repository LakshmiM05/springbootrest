package com.att.tuv.dao.employee;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.att.tuv.entity.Employee;

@Repository
public interface EmployeeDAO {
	public Employee getEmployee(int empId);

	public List<Employee> getAllEmployee();
}
