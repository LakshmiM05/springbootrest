package com.att.tuv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiveTuvJbossApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiveTuvJbossApplication.class, args);
	}
}
