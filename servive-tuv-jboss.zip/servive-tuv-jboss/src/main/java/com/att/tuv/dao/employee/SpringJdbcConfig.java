package com.att.tuv.dao.employee;

import javax.sql.DataSource;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@SpringBootConfiguration
public class SpringJdbcConfig {
	
	/*@Bean
	public SimpleJdbcCall simpleJdbcCall(DataSource dataSource)	
		{		
		return new SimpleJdbcCall(dataSource);
	}	
	
	
	@Bean(name="employeeDAOImpl")
    public EmployeeDAOImpl employeeDAOImpl(DataSource dataSource) {
        return new EmployeeDAOImpl(dataSource);
    }*/
	
	
	@Bean
	public DataSource dataSource() {
	DriverManagerDataSource dataSource = new DriverManagerDataSource();
	dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	dataSource.setUrl("jdbc:mysql://localhost:3306/TUV");
	dataSource.setUsername("root");
	dataSource.setPassword("root");	
return dataSource;
	}
	
	

}
